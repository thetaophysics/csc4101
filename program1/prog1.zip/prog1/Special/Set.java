// Set -- Parse tree node strategy for printing the special form set!

package Special;

import Tree.Node;

public class Set extends Special {
 
    public void print(Node t, int n, boolean p) {
    }

    public Set() {}
}