// Regular -- Parse tree node stratagy for printing regular lists

package Special;

import Tree.Node;

public class Regular extends Special {
 
    public void print(Node t, int n, boolean p) {
    }

    public Regular() {}
    
}